#ghost game
from random import randint
from time import sleep


score = 0
brave = True
ghost_num = 0
door_num = 0


while brave:
    ghost_num = randint(1, 3)
    print("Перед тобой 3 двери")
    print("За одной из них призрак")
    print("Какую дверь ты выберишь чтобы пройти дальше?")
    door_num = int(input("Номер двери: "))
    if door_num > 0 and door_num < 4:
        if door_num == ghost_num:
            print("За этой дверью призрак!")
            print("Игра закончена!")
            print("Ваш счёт", score)
            brave = False
        else:
            print("Тебе повезло, но будь осторожен")
            print("За дверью нет призраков, и ты проходишь далее")
            score += 1
            print("Счёт", score, "\n\n\n")
    else:
        print("Мы читеров не баним, но и играть с ними не будем")
        print("Тут нет двери с номером", door_num, "\n\n\n")
    sleep(1.5)
